using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ControladorEscenas : MonoBehaviour
{

    void Start()
    {
        
    }

   
    void Update()
    {
        
    }
     public void VerScoreboard()
    {
        SceneManager.LoadScene("ScoreBoard");
    }
}


