using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Logro
{
    public string nombre;
    public string descripcion;
    public bool desbloqueado;
    public float progresoRequerido;
}

